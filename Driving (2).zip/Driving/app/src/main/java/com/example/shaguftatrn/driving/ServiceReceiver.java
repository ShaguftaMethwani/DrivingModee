/*package com.example.shaguftatrn.driving;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.PhoneStateListener;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.widget.Switch;

/**
 * Created by shagufta.TRN on 8/24/2016.

public class ServiceReceiver extends BroadcastReceiver {
String incom;
    @Override
    public void onReceive(final Context context, Intent intent) {

        Log.v("received","hhhh");
        TelephonyManager telephony = (TelephonyManager)context.getSystemService(Context.TELEPHONY_SERVICE);
        telephony.listen(new PhoneStateListener(){
            @Override
            public void onCallStateChanged(int state, String incomingNumber) {
                super.onCallStateChanged(state, incomingNumber);
                incom=incomingNumber;
                Log.v("andand",incom+" helloo");

                /*SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(incom, null, "sms message", null, null);*/



               /* Intent intent=new Intent(getApplicationContext(),MainActivity.class);
                PendingIntent pi= PendingIntent.getActivity(getApplicationContext(), 0, intent,0);

                //Get the SmsManager instance and call the sendTextMessage method to send message
                SmsManager sms=SmsManager.getDefault();
                sms.sendTextMessage("8802177690", null, "hello javatpoint", pi,null);





            }
        },PhoneStateListener.LISTEN_CALL_STATE);
    }
}*/