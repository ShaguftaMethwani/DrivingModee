package com.example.shaguftatrn.driving;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.AudioManager;
import android.net.Uri;
import android.provider.Settings;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.MenuItem;
import android.widget.CompoundButton;
import android.widget.Switch;

public class MainActivity extends AppCompatActivity {
    public final static int REQUEST_CODE = 5454;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setCustomView(R.layout.switch_layout);
        actionBar.setDisplayOptions(ActionBar.DISPLAY_SHOW_HOME | ActionBar.DISPLAY_SHOW_CUSTOM);

        Switch button = (Switch) findViewById(R.id.actionbar_switch);

        if (!Settings.canDrawOverlays(this)) {
            /** if not construct intent to request permission */
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            /** request permission via start activity for result */
            startActivityForResult(intent, REQUEST_CODE);


        }

        Switch onOffSwitch = (Switch)  findViewById(R.id.actionbar_switch);
        onOffSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            BroadcastReceiver myBroadcastReceiver =
                    new BroadcastReceiver() {
                        @Override
                        public void onReceive(final Context context, Intent intent) {
                            Log.v("received","hhhh");
                            TelephonyManager telephony = (TelephonyManager)context.getSystemService(Context.TELEPHONY_SERVICE);
                            telephony.listen(new PhoneStateListener(){
                                @Override
                                public void onCallStateChanged(int state, String incomingNumber) {
                                    super.onCallStateChanged(state, incomingNumber);

                                    Log.v("andand",incomingNumber+" helloo");

                /*SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(incom, null, "sms message", null, null);*/



               /* Intent intent=new Intent(getApplicationContext(),MainActivity.class);
                PendingIntent pi= PendingIntent.getActivity(getApplicationContext(), 0, intent,0);

                //Get the SmsManager instance and call the sendTextMessage method to send message
                SmsManager sms=SmsManager.getDefault();
                sms.sendTextMessage("8802177690", null, "hello javatpoint", pi,null);*/





                                }
                            },PhoneStateListener.LISTEN_CALL_STATE);
                        }
                    };
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                IntentFilter filter = new IntentFilter();
                filter.addAction("android.intent.action.PHONE_STATE");
                if (isChecked==true){
                    AudioManager audiomanage = (AudioManager)getSystemService(Context.AUDIO_SERVICE);
                    audiomanage.setRingerMode(AudioManager.RINGER_MODE_SILENT);

                    registerReceiver(myBroadcastReceiver,filter);


                }
                else{
                    AudioManager audiomanage = (AudioManager)getSystemService(Context.AUDIO_SERVICE);
                audiomanage.setRingerMode(AudioManager.RINGER_MODE_NORMAL);
                unregisterReceiver(myBroadcastReceiver);
                }
            }

        });
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode,  Intent data) {

        /** check if received result code
         is equal our requested code for draw permission  */
        if (requestCode == REQUEST_CODE) {
            /** if so check once again if we have permission */
            if (Settings.canDrawOverlays(this)) {
                // continue here - permission was granted
                Intent intent = new Intent(MainActivity.this, FloatingFaceBubbleService.class);
                startService(intent);
            }
        }

    }
    }
